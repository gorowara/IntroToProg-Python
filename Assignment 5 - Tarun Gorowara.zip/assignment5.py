#-----------------------------------------#
# Title: Assignment 5
# Dev: Tarun Gorowara
# Desc: Create a new script that manages a "ToDo list." The ToDo file will contain two columns of data (Task, Priority)
# which you will store in a Python dictionary. Each Dictionary will represent one row of data. Which will then be added
# to a Python List to create a table of data. The program also allows the user to add or remove tasks from the list
# using numbered choices.
#------------------------------------------#

#-- Data --#
# Use square brackets to create a list
list = []

# Open the text file for reading ("r' mode)
objFH = open("C:\\_PythonClass\\ToDo.txt", "r")

#-- Processing --#
# Sorts each line that is already in txt file into dictionaries then append the dictionaries to "list".
for line in objFH:
    line = line.strip("\n")

    # Split string into a list to manipulate the values
    items = line.split(",")
    strTask, strPriority = items

    # Create a dictionary to add to the toDoList list (use curly braces to create dictionaries)
    # Each dictionary is one row of data
    row = {strTask : strPriority}

    # Add the dictionary to the "list"
    list.append(row)
objFH.close()

# Display the contents of the list to the user
def displayList():
    #Display header
    header = ("Task" + "\t       " + "Priority")
    print(header)

    #Display each row of data
    for row in list:
        for strTask, strPriority in row.items():
            displayRow = (strTask + "\t  " + strPriority)
            print(displayRow)
displayList()

#-- Presentation (Input/Output) --#
# Allow the user to Add or Remove tasks from the list using numbered choices
while True:
    print ("\nChoose 1 to Add task")
    print ("Choose 2 to Remove task")
    print ("Choose 3 to Save all tasks to the ToDo.txt file and exit!\n")
    numChoice = raw_input()

    # If user enters 1, ask user for a new task to add
    if numChoice == "1":
        strTask = raw_input("Please enter a new task: ")
        strPriority = raw_input("Please enter the new task's priority (low, medium, high): \n")

        # Make sure priority is entered correctly
        if strPriority.lower() == "low" or strPriority.lower() == "medium" or strPriority.lower() == "high":
            # Create a new dictionary to add to list
            newRow = {strTask: strPriority}

            # Add new dictionary and display updated list
            list.append(newRow)
            print
            displayList()
        else:
            print("Priority must be low, medium or high.\n")

    # If user enters 2, remove the task
    elif numChoice == "2":
        removeTask = raw_input("Please enter the task to be removed: ")

        # Check all rows for the task
        for row in list:
            for findTask in row:
                # Retrieve the key
                getTask = row.keys()

                # Convert to string
                stringTask = "".join(getTask)

                # Remove task if found
                if removeTask.lower() == stringTask.lower():
                    list.remove(row)
                    print
                    displayList()

    # If user enters 3, break from While loop and save the tasks
    elif numChoice == '3':
        break

    # If user enters an invalid number
    else:
        print ("Invalid choice! Please enter 1, 2, or 3")

# Get each dictionary as a tuple and write to file
objFH = open("C:\\_PythonClass\\ToDo.txt", "w")

# For each row in the list, write the task and associated priority on the same line
for row in list:
    for (strTask, strPriority) in row.items():
        line = (strTask + ", " + strPriority + "\n")
        objFH.write(line)
objFH.close()

print ("Your tasks have been saved to file, ToDo.txt")